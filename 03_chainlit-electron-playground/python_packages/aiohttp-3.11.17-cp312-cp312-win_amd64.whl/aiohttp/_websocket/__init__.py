"""WebSocket protocol versions 13 and 8."""
