"""Uptrace distro version"""

__version__ = "1.31.0"
